public class ErreurCoordonneesException extends Exception {
    int x,y ;

    public getMessage()
}

